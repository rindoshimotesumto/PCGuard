import re
import subprocess


TSHARK_PATH = r"C:\Program Files\Wireshark\tshark.exe"


def _run_powershell(command: str) -> str:
    result = subprocess.run(
        [
            "powershell",
            "-NoProfile",
            "-Command",
            command,
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="ignore",
    )

    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip())

    return result.stdout.strip()


def get_active_interface_index() -> int:
    result = _run_powershell(
        """
        $route = Get-NetRoute -DestinationPrefix '0.0.0.0/0' |
            Where-Object {$_.State -eq 'Alive'} |
            Sort-Object RouteMetric, InterfaceMetric |
            Select-Object -First 1

        $route.InterfaceIndex
        """
    )

    if not result:
        raise RuntimeError("Active interface not found")

    return int(result)


def get_active_adapter_name() -> str:
    interface_index = get_active_interface_index()

    result = _run_powershell(
        f"""
        (Get-NetAdapter `
            -InterfaceIndex {interface_index}
        ).Name
        """
    )

    if not result:
        raise RuntimeError("Active adapter name not found")

    return result


def get_active_ipv4() -> str:
    interface_index = get_active_interface_index()

    result = _run_powershell(
        f"""
        (Get-NetIPAddress `
            -InterfaceIndex {interface_index} `
            -AddressFamily IPv4 |
            Where-Object {{
                $_.AddressState -eq 'Preferred'
            }} |
            Select-Object -First 1
        ).IPAddress
        """
    )

    if not result:
        raise RuntimeError("Active IPv4 not found")

    return result


def get_tshark_interface_number() -> str:
    adapter_name = get_active_adapter_name()

    result = subprocess.run(
        [TSHARK_PATH, "-D"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="ignore",
    )

    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip())

    for line in result.stdout.splitlines():
        if adapter_name.lower() not in line.lower():
            continue

        match = re.match(r"^\s*(\d+)\.", line)

        if match:
            return match.group(1)

    raise RuntimeError(
        f"TShark interface not found for: {adapter_name}"
    )