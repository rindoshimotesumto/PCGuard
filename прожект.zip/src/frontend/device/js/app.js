const state = {
  data: null,
  timer: null,
  refreshMs: 3000,
};

const API = {
  trafficCandidates: [
    "/eth-traffic/current",
    "/eth-traffic/traffic",
    "/eth-traffic",
  ],
  startCandidates: [
    "/eth-traffic/run-scan",
    "/eth-traffic/scan",
  ],
  stopCandidates: [
    "/eth-traffic/stop-scan",
  ],
};

const $ = id => document.getElementById(id);
const els = {
  rows: $("trafficRows"),
  search: $("search"),
  totalDownload: $("totalDownload"),
  totalUpload: $("totalUpload"),
  totalSites: $("totalSites"),
  totalPackets: $("totalPackets"),
  shownText: $("shownText"),
  periodText: $("periodText"),
  lastUpdated: $("lastUpdated"),
  apiState: $("apiState"),
  notice: $("notice"),
  settingsBtn: $("settingsBtn"),
  settingsPopover: $("settingsPopover"),
  apiBase: $("apiBase"),
  saveApiBase: $("saveApiBase"),
  startScanBtn: $("startScanBtn"),
  stopScanBtn: $("stopScanBtn"),
  refreshBtn: $("refreshBtn"),
};

function getApiBase(){
  const saved = localStorage.getItem("pcguard-api-base");
  if(saved) return saved.replace(/\/$/, "");
  return window.location.origin === "null" ? "http://127.0.0.1:8000" : window.location.origin;
}

function buildUrl(path){
  return `${getApiBase()}${path}`;
}

async function fetchFirst(paths, options = {}){
  let lastError = null;

  for(const path of paths){
    try{
      const response = await fetch(buildUrl(path), {
        method: "GET",
        cache: "no-store",
        ...options,
      });

      if(response.ok){
        const type = response.headers.get("content-type") || "";
        return type.includes("application/json") ? await response.json() : await response.text();
      }

      lastError = new Error(`${response.status} ${response.statusText} — ${path}`);
    }catch(error){
      lastError = error;
    }
  }

  throw lastError || new Error("API endpoint not found");
}

function setApiState(mode, text){
  els.apiState.classList.remove("ok", "error");
  if(mode) els.apiState.classList.add(mode);
  els.apiState.querySelector("span:last-child").textContent = text;
}

function showNotice(message, type = "error"){
  els.notice.hidden = !message;
  els.notice.className = `notice ${type}`;
  els.notice.textContent = message || "";
}

function formatBytesFromMb(value){
  const mb = Number(value || 0);
  const bytes = mb * 1024 * 1024;
  if(bytes < 1024) return `${bytes.toFixed(0)} B`;
  if(bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  if(bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(2)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
}

function formatNumber(value){
  return new Intl.NumberFormat("ru-RU").format(Number(value || 0));
}

function formatDateTime(value){
  if(!value) return "—";
  const date = new Date(value);
  if(Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(date);
}

function escapeHtml(value){
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function relativeActivity(lastSeen){
  if(!lastSeen) return "нет данных";
  const diff = Math.max(0, Date.now() - new Date(lastSeen).getTime());
  const seconds = Math.floor(diff / 1000);
  if(seconds < 10) return "активен сейчас";
  if(seconds < 60) return `${seconds} сек. назад`;
  const minutes = Math.floor(seconds / 60);
  if(minutes < 60) return `${minutes} мин. назад`;
  return formatDateTime(lastSeen);
}

function normalizePayload(payload){
  return {
    from_date: payload?.from_date ?? payload?.on_date ?? null,
    to_date: payload?.to_date ?? null,
    total_upload_mb: Number(payload?.total_upload_mb || 0),
    total_download_mb: Number(payload?.total_download_mb || 0),
    by_url: Array.isArray(payload?.by_url) ? payload.by_url : [],
  };
}

function render(){
  if(!state.data) return;

  const data = state.data;
  const query = (els.search.value || "").trim().toLowerCase();
  const rows = data.by_url
    .filter(item => !query || String(item.url || "").toLowerCase().includes(query))
    .sort((a, b) => {
      const aTraffic = Number(a.total_download_mb || 0) + Number(a.total_upload_mb || 0);
      const bTraffic = Number(b.total_download_mb || 0) + Number(b.total_upload_mb || 0);
      return bTraffic - aTraffic;
    });

  els.totalDownload.textContent = formatBytesFromMb(data.total_download_mb);
  els.totalUpload.textContent = formatBytesFromMb(data.total_upload_mb);
  els.totalSites.textContent = formatNumber(data.by_url.length);
  els.totalPackets.textContent = formatNumber(
    data.by_url.reduce((sum, item) => sum + Number(item.traffic_packet_count || 0), 0)
  );

  if(!rows.length){
    els.rows.innerHTML = `<tr class="empty-row"><td colspan="6">${query ? "По запросу ничего не найдено" : "Трафик пока не определён"}</td></tr>`;
  }else{
    els.rows.innerHTML = rows.map(item => {
      const domain = String(item.url || "unknown");
      const firstLetter = domain.replace(/^www\./, "").charAt(0).toUpperCase() || "?";
      return `
        <tr>
          <td>
            <div class="domain-cell">
              <div class="domain-icon">${escapeHtml(firstLetter)}</div>
              <div class="domain-text">
                <div class="domain-name">${escapeHtml(domain)}</div>
                <div class="domain-activity">${escapeHtml(relativeActivity(item.last_seen_at))}</div>
              </div>
            </div>
          </td>
          <td class="amount">${formatBytesFromMb(item.total_download_mb)}</td>
          <td class="amount">${formatBytesFromMb(item.total_upload_mb)}</td>
          <td class="packet-count">${formatNumber(item.traffic_packet_count)}</td>
          <td class="time">${formatDateTime(item.first_seen_at)}</td>
          <td class="time">${formatDateTime(item.last_seen_at)}</td>
        </tr>`;
    }).join("");
  }

  els.shownText.textContent = `${rows.length} из ${data.by_url.length} сайтов`;
  els.periodText.textContent = data.from_date
    ? `${data.from_date}${data.to_date && data.to_date !== data.from_date ? ` — ${data.to_date}` : ""}`
    : "—";
}

async function loadTraffic({silent = false} = {}){
  try{
    const payload = await fetchFirst(API.trafficCandidates);
    state.data = normalizePayload(payload);
    render();
    els.lastUpdated.textContent = `Обновлено ${new Intl.DateTimeFormat("ru-RU", {hour:"2-digit", minute:"2-digit", second:"2-digit"}).format(new Date())}`;
    setApiState("ok", "API доступен");
    if(!silent) showNotice("", "success");
  }catch(error){
    setApiState("error", "API недоступен");
    if(!silent){
      showNotice(`Не удалось получить интернет-трафик. Проверь API Base URL и endpoint. ${error?.message || error}`);
    }
  }
}

async function startScan(){
  els.startScanBtn.disabled = true;
  try{
    await fetchFirst(API.startCandidates);
    showNotice("Сканирование запущено", "success");
    await loadTraffic({silent:true});
  }catch(error){
    showNotice(`Не удалось запустить сканирование: ${error?.message || error}`);
  }finally{
    els.startScanBtn.disabled = false;
  }
}

async function stopScan(){
  els.stopScanBtn.disabled = true;
  try{
    await fetchFirst(API.stopCandidates);
    showNotice("Сканирование остановлено", "success");
    await loadTraffic({silent:true});
  }catch(error){
    showNotice(`Не удалось остановить сканирование: ${error?.message || error}`);
  }finally{
    els.stopScanBtn.disabled = false;
  }
}

function initSettings(){
  els.apiBase.value = getApiBase();

  els.settingsBtn.addEventListener("click", event => {
    event.stopPropagation();
    els.settingsPopover.hidden = !els.settingsPopover.hidden;
  });

  els.settingsPopover.addEventListener("click", event => event.stopPropagation());
  document.addEventListener("click", () => els.settingsPopover.hidden = true);

  els.saveApiBase.addEventListener("click", async () => {
    const value = els.apiBase.value.trim().replace(/\/$/, "");
    if(value) localStorage.setItem("pcguard-api-base", value);
    else localStorage.removeItem("pcguard-api-base");
    els.settingsPopover.hidden = true;
    await loadTraffic();
  });
}

function initDeviceLabel(){
  const id = new URLSearchParams(location.search).get("id");
  if(id){
    $("deviceTitle").textContent = `Устройство ${id}`;
  }
}

els.search.addEventListener("input", render);
els.refreshBtn.addEventListener("click", () => loadTraffic());
els.startScanBtn.addEventListener("click", startScan);
els.stopScanBtn.addEventListener("click", stopScan);

initSettings();
initDeviceLabel();
loadTraffic();
state.timer = setInterval(() => loadTraffic({silent:true}), state.refreshMs);
